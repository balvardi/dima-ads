<?php
/**
 * Plugin Name: Dima Ads
 * Plugin URI: https://dimagroup.ir/dima-ads
 * Description: A secure plugin to allow users to submit advertisements for admin approval.
 * Version: 1.0
 * Author: R.Balvardi
 * Author URI: https://dimagroup.ir
 * License: GPLv2 or later
 * Text Domain: dima-ads
 */

// جلوگیری از دسترسی مستقیم به فایل
if (!defined('ABSPATH')) {
    exit;
}

// ایجاد جدول در دیتابیس هنگام فعال‌سازی پلاگین
function dima_ads_activate() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'dima_ads';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        title varchar(255) NOT NULL,
        description text NOT NULL,
        status varchar(20) DEFAULT 'pending',
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);
}
register_activation_hook(__FILE__, 'dima_ads_activate');

// حذف جدول هنگام غیرفعال‌سازی پلاگین (اختیاری)
function dima_ads_deactivate() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'dima_ads';
    $wpdb->query("DROP TABLE IF EXISTS $table_name");
}
register_deactivation_hook(__FILE__, 'dima_ads_deactivate');

// اضافه کردن منوی پلاگین به داشبورد وردپرس
function dima_ads_menu() {
    add_menu_page(
        'Dima Ads', 
        'Dima Ads', 
        'manage_options', 
        'dima-ads', 
        'dima_ads_admin_page', 
        'dashicons-megaphone', 
        6
    );
}
add_action('admin_menu', 'dima_ads_menu');

// صفحه مدیریت تبلیغات
function dima_ads_admin_page() {
    global $wpdb;
    $table_name = $wpdb->prefix . 'dima_ads';

    // اعتبارسنجی CSRF برای عملیات تأیید و رد
    if (isset($_GET['action']) && isset($_GET['id']) && isset($_GET['_wpnonce'])) {
        if (!wp_verify_nonce($_GET['_wpnonce'], 'ad_action_' . $_GET['id'])) {
            wp_die(__('Security check failed!', 'dima-ads'));
        }

        $id = intval($_GET['id']);
        if ($_GET['action'] == 'approve') {
            $wpdb->update($table_name, ['status' => 'approved'], ['id' => $id]);
        } elseif ($_GET['action'] == 'reject') {
            $wpdb->update($table_name, ['status' => 'rejected'], ['id' => $id]);
        }
    }

    $ads = $wpdb->get_results("SELECT * FROM $table_name");

    echo '<div class="wrap">';
    echo '<h1>' . __('Manage Advertisements', 'dima-ads') . '</h1>';
    echo '<table class="wp-list-table widefat fixed striped">';
    echo '<thead><tr><th>ID</th><th>Title</th><th>Description</th><th>Status</th><th>Actions</th></tr></thead>';
    echo '<tbody>';
    foreach ($ads as $ad) {
        echo '<tr>';
        echo '<td>' . esc_html($ad->id) . '</td>';
        echo '<td>' . esc_html($ad->title) . '</td>';
        echo '<td>' . esc_html(wp_trim_words($ad->description, 20)) . '</td>';
        echo '<td>' . esc_html($ad->status) . '</td>';
        echo '<td>';
        if ($ad->status == 'pending') {
            $approve_url = wp_nonce_url(add_query_arg(['action' => 'approve', 'id' => $ad->id]), 'ad_action_' . $ad->id);
            $reject_url = wp_nonce_url(add_query_arg(['action' => 'reject', 'id' => $ad->id]), 'ad_action_' . $ad->id);
            echo '<a href="' . esc_url($approve_url) . '" class="button button-primary">' . __('Approve', 'dima-ads') . '</a> ';
            echo '<a href="' . esc_url($reject_url) . '" class="button button-secondary">' . __('Reject', 'dima-ads') . '</a>';
        }
        echo '</td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
    echo '</div>';
}

// فرم ثبت تبلیغ برای کاربران
function dima_ads_shortcode() {
    ob_start();
    if (!is_user_logged_in()) {
        echo '<div class="alert alert-warning">' . __('You must be logged in to submit an advertisement.', 'dima-ads') . '</div>';
        return ob_get_clean();
    }

    global $wpdb;
    $table_name = $wpdb->prefix . 'dima_ads';
    $user_id = get_current_user_id();

    // بررسی تعداد آگهی‌های ثبت‌شده توسط کاربر
    $count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $table_name WHERE user_id = %d", $user_id));
    $max_ads = 3; // حداکثر تعداد آگهی‌های مجاز برای هر کاربر

    if ($count >= $max_ads) {
        echo '<div class="alert alert-danger">' . sprintf(__('You have reached the maximum number of advertisements (%d).', 'dima-ads'), $max_ads) . '</div>';
        return ob_get_clean();
    }

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_ad'])) {
        // اعتبارسنجی CSRF
        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'submit_advertisement')) {
            wp_die(__('Security check failed!', 'dima-ads'));
        }

        $title = sanitize_text_field($_POST['title']);
        $description = sanitize_textarea_field($_POST['description']);

        if (!empty($title) && !empty($description)) {
            $wpdb->insert($table_name, [
                'user_id' => $user_id,
                'title' => $title,
                'description' => $description,
                'status' => 'pending'
            ]);
            echo '<div class="alert alert-success">' . __('Your advertisement has been submitted and is pending approval.', 'dima-ads') . '</div>';
        } else {
            echo '<div class="alert alert-danger">' . __('Please fill in all fields.', 'dima-ads') . '</div>';
        }
    }

    ?>
    <form method="post" class="ad-form">
        <?php wp_nonce_field('submit_advertisement'); ?>
        <div class="form-group">
            <label for="title"><?php _e('Title:', 'dima-ads'); ?></label>
            <input type="text" name="title" id="title" class="form-control" required>
        </div>
        <div class="form-group">
            <label for="description"><?php _e('Description:', 'dima-ads'); ?></label>
            <textarea name="description" id="description" class="form-control" rows="5" required></textarea>
        </div>
        <button type="submit" name="submit_ad" class="btn btn-primary"><?php _e('Submit Advertisement', 'dima-ads'); ?></button>
    </form>
    <?php
    return ob_get_clean();
}
add_shortcode('submit_advertisement', 'dima_ads_shortcode');

// اضافه کردن استایل‌ها و اسکریپت‌ها
function dima_ads_enqueue_scripts() {
    wp_enqueue_style('bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css');
    wp_enqueue_script('jquery');
}
add_action('wp_enqueue_scripts', 'dima_ads_enqueue_scripts');