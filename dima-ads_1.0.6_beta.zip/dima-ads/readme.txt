=== Dima Ads ===
Contributors: yourname
Tags: ads, advertisement, classifieds, wordpress
Requires at least: 5.0
Tested up to: 6.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A secure WordPress plugin that allows users to submit advertisements for admin approval.

== Description ==

Dima Ads is a WordPress plugin designed to let users submit advertisements via a shortcode. Admins can approve or reject submissions from the dashboard. The plugin includes security measures such as CSRF protection, SQL injection prevention, and XSS protection.

**Features:**
- Secure submission form with nonce validation.
- Admin dashboard for managing advertisements.
- Limit on the number of ads per user.
- Bootstrap styling for a clean UI.

== Installation ==

1. Upload the `dima-ads` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Use the `[submit_advertisement]` shortcode to display the ad submission form.

== Frequently Asked Questions ==

= How do I use the plugin? =
Use the `[submit_advertisement]` shortcode in any post or page to display the ad submission form.

= Can users submit unlimited ads? =
No, each user can submit a limited number of ads (default is 3).

== Changelog ==

= 1.0 =
* Initial release.

== Upgrade Notice ==

None.