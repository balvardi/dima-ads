<?php
/**
 * Plugin Name: Dima Ads
 * Plugin URI: https://dimagroup.ir
 * Description: A secure plugin to allow users to submit advertisements with contact info, image, and description using Bootstrap for styling.
 * Version: 1.5
 * Author: R.Balvardi
 * Author URI: https://github.com/balvardi
 * License: GPLv2 or later
 * Text Domain: dima-ads
 */

// جلوگیری از دسترسی مستقیم به فایل
if (!defined('ABSPATH')) {
    exit;
}

// بارگذاری فایل‌های ترجمه
function dima_ads_load_textdomain() {
    load_plugin_textdomain('dima-ads', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}
add_action('plugins_loaded', 'dima_ads_load_textdomain');

// ایجاد جدول دسته‌بندی‌ها و تبلیغات در دیتابیس هنگام فعال‌سازی پلاگین
function dima_ads_activate() {
    global $wpdb;
    $charset_collate = $wpdb->get_charset_collate();

    // جدول دسته‌بندی‌ها
    $categories_table = $wpdb->prefix . 'dima_ad_categories';
    $sql_categories = "CREATE TABLE IF NOT EXISTS $categories_table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        name varchar(255) NOT NULL,
        slug varchar(255) NOT NULL,
        PRIMARY KEY (id)
    ) $charset_collate;";

    // جدول تبلیغات
    $ads_table = $wpdb->prefix . 'dima_ads';
    $sql_ads = "CREATE TABLE IF NOT EXISTS $ads_table (
        id mediumint(9) NOT NULL AUTO_INCREMENT,
        user_id bigint(20) NOT NULL,
        category_id mediumint(9) DEFAULT NULL,
        title varchar(255) NOT NULL,
        description text NOT NULL,
        contact_info text NOT NULL,
        image_url varchar(255) DEFAULT NULL,
        status varchar(20) DEFAULT 'pending',
        created_at datetime DEFAULT CURRENT_TIMESTAMP,
        PRIMARY KEY (id)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql_categories);
    dbDelta($sql_ads);
}
register_activation_hook(__FILE__, 'dima_ads_activate');

// حذف جداول هنگام غیرفعال‌سازی پلاگین (اختیاری)
function dima_ads_deactivate() {
    global $wpdb;
    $categories_table = $wpdb->prefix . 'dima_ad_categories';
    $ads_table = $wpdb->prefix . 'dima_ads';
    $wpdb->query("DROP TABLE IF EXISTS $categories_table");
    $wpdb->query("DROP TABLE IF EXISTS $ads_table");
}
register_deactivation_hook(__FILE__, 'dima_ads_deactivate');

// اضافه کردن منوهای اختصاصی به داشبورد وردپرس
function dima_ads_admin_menu() {
    // صفحه مدیریت دسته‌بندی‌ها
    add_menu_page(
        __('Ad Categories', 'dima-ads'),
        __('Categories', 'dima-ads'),
        'manage_options',
        'dima-ad-categories',
        'dima_ads_categories_page',
        'dashicons-category',
        6
    );

    // صفحه لیست کل تبلیغات برای ادمین
    add_menu_page(
        __('All Advertisements', 'dima-ads'),
        __('All Ads', 'dima-ads'),
        'manage_options',
        'all-advertisements',
        'dima_ads_all_ads_page',
        'dashicons-list-view',
        7
    );

    // صفحه لیست تبلیغات کاربر
    add_menu_page(
        __('My Advertisements', 'dima-ads'),
        __('My Ads', 'dima-ads'),
        'read',
        'my-advertisements',
        'dima_ads_user_ad_list',
        'dashicons-clipboard',
        8
    );

    // صفحه ثبت تبلیغ جدید
    add_menu_page(
        __('Submit Advertisement', 'dima-ads'),
        __('Submit Ad', 'dima-ads'),
        'read',
        'submit-advertisement',
        'dima_ads_custom_submit_form',
        'dashicons-megaphone',
        9
    );
}
add_action('admin_menu', 'dima_ads_admin_menu');

// صفحه مدیریت دسته‌بندی‌ها
function dima_ads_categories_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.', 'dima-ads'));
    }

    global $wpdb;
    $categories_table = $wpdb->prefix . 'dima_ad_categories';

    // افزودن دسته‌بندی جدید
    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_category'])) {
        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'add_category')) {
            wp_die(__('Security check failed!', 'dima-ads'));
        }

        $name = sanitize_text_field($_POST['category_name']);
        $slug = sanitize_title($name);

        if (!empty($name)) {
            $wpdb->insert($categories_table, [
                'name' => $name,
                'slug' => $slug
            ]);
        }
    }

    // حذف دسته‌بندی
    if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id']) && isset($_GET['_wpnonce'])) {
        if (!wp_verify_nonce($_GET['_wpnonce'], 'delete_category_' . $_GET['id'])) {
            wp_die(__('Security check failed!', 'dima-ads'));
        }

        $id = intval($_GET['id']);
        $wpdb->delete($categories_table, ['id' => $id]);
    }

    $categories = $wpdb->get_results("SELECT * FROM $categories_table");

    echo '<div class="wrap">';
    echo '<h1>' . __('Ad Categories', 'dima-ads') . '</h1>';

    // فرم افزودن دسته‌بندی
    echo '<form method="post" class="ad-category-form">';
    wp_nonce_field('add_category');
    echo '<div class="mb-3">';
    echo '<label for="category_name" class="form-label">' . __('Category Name:', 'dima-ads') . '</label>';
    echo '<input type="text" name="category_name" id="category_name" class="form-control" required>';
    echo '</div>';
    echo '<button type="submit" name="add_category" class="btn btn-primary">' . __('Add Category', 'dima-ads') . '</button>';
    echo '</form>';

    // لیست دسته‌بندی‌ها
    if (!empty($categories)) {
        echo '<table class="table table-striped mt-4">';
        echo '<thead><tr><th>ID</th><th>Name</th><th>Slug</th><th>Actions</th></tr></thead>';
        echo '<tbody>';
        foreach ($categories as $category) {
            echo '<tr>';
            echo '<td>' . esc_html($category->id) . '</td>';
            echo '<td>' . esc_html($category->name) . '</td>';
            echo '<td>' . esc_html($category->slug) . '</td>';
            echo '<td>';
            $delete_url = wp_nonce_url(add_query_arg(['action' => 'delete', 'id' => $category->id]), 'delete_category_' . $category->id);
            echo '<a href="' . esc_url($delete_url) . '" class="btn btn-danger btn-sm">' . __('Delete', 'dima-ads') . '</a>';
            echo '</td>';
            echo '</tr>';
        }
        echo '</tbody></table>';
    } else {
        echo '<p>' . __('No categories found.', 'dima-ads') . '</p>';
    }
    echo '</div>';
}

// صفحه لیست کل تبلیغات برای ادمین
function dima_ads_all_ads_page() {
    if (!current_user_can('manage_options')) {
        wp_die(__('You do not have sufficient permissions to access this page.', 'dima-ads'));
    }

    global $wpdb;
    $ads_table = $wpdb->prefix . 'dima_ads';
    $categories_table = $wpdb->prefix . 'dima_ad_categories';

    // عملیات تأیید یا رد آگهی
    if (isset($_GET['action']) && isset($_GET['id']) && isset($_GET['_wpnonce'])) {
        if (!wp_verify_nonce($_GET['_wpnonce'], 'ad_action_' . $_GET['id'])) {
            wp_die(__('Security check failed!', 'dima-ads'));
        }

        $id = intval($_GET['id']);
        if ($_GET['action'] == 'approve') {
            $wpdb->update($ads_table, ['status' => 'approved'], ['id' => $id]);
        } elseif ($_GET['action'] == 'reject') {
            $wpdb->update($ads_table, ['status' => 'rejected'], ['id' => $id]);
        }
    }

    $ads = $wpdb->get_results("SELECT ads.*, categories.name AS category_name 
                               FROM $ads_table ads
                               LEFT JOIN {$wpdb->prefix}dima_ad_categories categories ON ads.category_id = categories.id");

    echo '<div class="wrap">';
    echo '<h1>' . __('All Advertisements', 'dima-ads') . '</h1>';

    if (empty($ads)) {
        echo '<p>' . __('No advertisements found.', 'dima-ads') . '</p>';
        return;
    }

    echo '<table class="table table-striped">';
    echo '<thead><tr><th>ID</th><th>Title</th><th>Category</th><th>Status</th><th>Actions</th></tr></thead>';
    echo '<tbody>';
    foreach ($ads as $ad) {
        echo '<tr>';
        echo '<td>' . esc_html($ad->id) . '</td>';
        echo '<td>' . esc_html($ad->title) . '</td>';
        echo '<td>' . esc_html($ad->category_name ?? __('Uncategorized', 'dima-ads')) . '</td>';
        echo '<td>' . esc_html($ad->status) . '</td>';
        echo '<td>';
        if ($ad->status == 'pending') {
            $approve_url = wp_nonce_url(add_query_arg(['action' => 'approve', 'id' => $ad->id]), 'ad_action_' . $ad->id);
            $reject_url = wp_nonce_url(add_query_arg(['action' => 'reject', 'id' => $ad->id]), 'ad_action_' . $ad->id);
            echo '<a href="' . esc_url($approve_url) . '" class="btn btn-success btn-sm">' . __('Approve', 'dima-ads') . '</a> ';
            echo '<a href="' . esc_url($reject_url) . '" class="btn btn-danger btn-sm">' . __('Reject', 'dima-ads') . '</a>';
        }
        echo '</td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
    echo '</div>';
}

// نمایش لیست آگهی‌های کاربر
function dima_ads_user_ad_list() {
    if (!is_user_logged_in()) {
        wp_die(__('You must be logged in to view your advertisements.', 'dima-ads'));
    }

    global $wpdb;
    $ads_table = $wpdb->prefix . 'dima_ads';
    $user_id = get_current_user_id();

    $ads = $wpdb->get_results($wpdb->prepare("SELECT * FROM $ads_table WHERE user_id = %d", $user_id));

    echo '<div class="wrap">';
    echo '<h1>' . __('My Advertisements', 'dima-ads') . '</h1>';

    if (empty($ads)) {
        echo '<div class="alert alert-info">' . __('You have not submitted any advertisements yet.', 'dima-ads') . '</div>';
        return;
    }

    echo '<table class="table table-striped">';
    echo '<thead><tr><th>ID</th><th>Title</th><th>Status</th><th>Submitted At</th></tr></thead>';
    echo '<tbody>';
    foreach ($ads as $ad) {
        echo '<tr>';
        echo '<td>' . esc_html($ad->id) . '</td>';
        echo '<td>' . esc_html($ad->title) . '</td>';
        echo '<td>' . esc_html($ad->status) . '</td>';
        echo '<td>' . esc_html($ad->created_at) . '</td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
    echo '</div>';
}

// نمایش فرم ثبت آگهی
function dima_ads_custom_submit_form() {
    if (!is_user_logged_in()) {
        wp_die(__('You must be logged in to submit an advertisement.', 'dima-ads'));
    }

    global $wpdb;
    $ads_table = $wpdb->prefix . 'dima_ads';
    $categories_table = $wpdb->prefix . 'dima_ad_categories';
    $user_id = get_current_user_id();

    // بررسی تعداد آگهی‌های ثبت‌شده توسط کاربر
    $count = $wpdb->get_var($wpdb->prepare("SELECT COUNT(*) FROM $ads_table WHERE user_id = %d", $user_id));
    $max_ads = 3; // حداکثر تعداد آگهی‌های مجاز برای هر کاربر

    if ($count >= $max_ads) {
        echo '<div class="alert alert-danger">' . sprintf(__('You have reached the maximum number of advertisements (%d).', 'dima-ads'), $max_ads) . '</div>';
        return;
    }

    $categories = $wpdb->get_results("SELECT * FROM $categories_table");

    if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['submit_ad'])) {
        // اعتبارسنجی CSRF
        if (!isset($_POST['_wpnonce']) || !wp_verify_nonce($_POST['_wpnonce'], 'submit_advertisement')) {
            wp_die(__('Security check failed!', 'dima-ads'));
        }

        $title = sanitize_text_field($_POST['title']);
        $description = sanitize_textarea_field($_POST['description']);
        $contact_info = sanitize_textarea_field($_POST['contact_info']);
        $image_url = esc_url_raw($_POST['image_url']);
        $category_id = intval($_POST['category_id']);

        if (!empty($title) && !empty($description) && !empty($contact_info)) {
            $wpdb->insert($ads_table, [
                'user_id' => $user_id,
                'category_id' => $category_id,
                'title' => $title,
                'description' => $description,
                'contact_info' => $contact_info,
                'image_url' => $image_url,
                'status' => 'pending'
            ]);
            echo '<div class="alert alert-success">' . __('Your advertisement has been submitted and is pending approval.', 'dima-ads') . '</div>';
        } else {
            echo '<div class="alert alert-danger">' . __('Please fill in all fields.', 'dima-ads') . '</div>';
        }
    }

    echo '<div class="wrap">';
    echo '<h1>' . __('Submit Advertisement', 'dima-ads') . '</h1>';
    ?>
    <form method="post" class="ad-form">
        <?php wp_nonce_field('submit_advertisement'); ?>
        <div class="mb-3">
            <label for="category_id" class="form-label"><?php _e('Category:', 'dima-ads'); ?></label>
            <select name="category_id" id="category_id" class="form-select" required>
                <option value=""><?php _e('Select a category', 'dima-ads'); ?></option>
                <?php foreach ($categories as $category): ?>
                    <option value="<?php echo esc_attr($category->id); ?>"><?php echo esc_html($category->name); ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="mb-3">
            <label for="title" class="form-label"><?php _e('Title:', 'dima-ads'); ?></label>
            <input type="text" name="title" id="title" class="form-control" required>
        </div>
        <div class="mb-3">
            <label for="description" class="form-label"><?php _e('Description:', 'dima-ads'); ?></label>
            <textarea name="description" id="description" class="form-control" rows="5" required></textarea>
        </div>
        <div class="mb-3">
            <label for="contact_info" class="form-label"><?php _e('Contact Information:', 'dima-ads'); ?></label>
            <textarea name="contact_info" id="contact_info" class="form-control" rows="3" required></textarea>
        </div>
        <div class="mb-3">
            <label for="image_url" class="form-label"><?php _e('Image URL:', 'dima-ads'); ?></label>
            <input type="url" name="image_url" id="image_url" class="form-control">
            <small class="form-text text-muted"><?php _e('Enter the URL of the image you want to display with your advertisement.', 'dima-ads'); ?></small>
        </div>
        <button type="submit" name="submit_ad" class="btn btn-primary"><?php _e('Submit Advertisement', 'dima-ads'); ?></button>
    </form>
    <?php
    echo '</div>';
}

// اضافه کردن استایل‌ها و اسکریپت‌ها
function dima_ads_enqueue_scripts() {
    wp_enqueue_style('bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css');
    wp_enqueue_script('bootstrap', 'https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js', array(), null, true);
}
add_action('admin_enqueue_scripts', 'dima_ads_enqueue_scripts');
// اضافه کردن شورتکد برای نمایش تبلیغات
function dima_ads_display_shortcode($atts) {
    global $wpdb;
    $ads_table = $wpdb->prefix . 'dima_ads';
    $categories_table = $wpdb->prefix . 'dima_ad_categories';

    // دریافت پارامترهای شورتکد (اختیاری)
    $atts = shortcode_atts([
        'category' => '', // دسته‌بندی خاص (اختیاری)
        'limit' => 10,   // حداکثر تعداد آگهی‌ها (پیش‌فرض: 10)
    ], $atts, 'display_ads');

    $category_slug = sanitize_text_field($atts['category']);
    $limit = intval($atts['limit']);

    // ساخت کوئری برای نمایش آگهی‌ها
    $query = "SELECT ads.*, categories.name AS category_name 
              FROM $ads_table ads
              LEFT JOIN $categories_table categories ON ads.category_id = categories.id
              WHERE ads.status = 'approved'";
    
    if (!empty($category_slug)) {
        $query .= $wpdb->prepare(" AND categories.slug = %s", $category_slug);
    }

    $query .= " ORDER BY ads.created_at DESC LIMIT %d";
    $query = $wpdb->prepare($query, $limit);

    $ads = $wpdb->get_results($query);

    // نمایش آگهی‌ها
    if (empty($ads)) {
        return '<p>' . __('No advertisements found.', 'dima-ads') . '</p>';
    }

    ob_start();
    echo '<div class="dima-ads-list">';
    foreach ($ads as $ad) {
        echo '<div class="dima-ad-item">';
        if (!empty($ad->image_url)) {
            echo '<img src="' . esc_url($ad->image_url) . '" alt="' . esc_attr($ad->title) . '" class="dima-ad-image">';
        }
        echo '<h3 class="dima-ad-title">' . esc_html($ad->title) . '</h3>';
        echo '<p class="dima-ad-description">' . wp_trim_words($ad->description, 20) . '</p>';
        echo '<p class="dima-ad-contact"><strong>' . __('Contact:', 'dima-ads') . '</strong> ' . esc_html($ad->contact_info) . '</p>';
        echo '<p class="dima-ad-category"><strong>' . __('Category:', 'dima-ads') . '</strong> ' . esc_html($ad->category_name) . '</p>';
        echo '</div>';
    }
    echo '</div>';
    return ob_get_clean();
}
add_shortcode('display_ads', 'dima_ads_display_shortcode');